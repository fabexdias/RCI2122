#ifndef _VERIFY_H_
#define _VERIFY_H_

int port_check(char *);
int key_check(char *);
int arg_check(int argc,char* argv[]);

#endif